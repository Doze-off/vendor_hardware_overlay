PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/device_X682C.mk

COMMON_LUNCH_CHOICES := \
    device_X682C-userdebug \
    device_X682C-user
