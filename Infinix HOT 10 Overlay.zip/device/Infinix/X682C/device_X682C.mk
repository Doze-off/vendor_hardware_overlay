# device_X682C.mk
PRODUCT_DEVICE := X682C
PRODUCT_NAME := full_X682C
PRODUCT_BRAND := Infinix
PRODUCT_MODEL := Infinix HOT 10
PRODUCT_BOARD := k61v1_64

# Inherit unified properties
TARGET_DEVICE_CHARACTERISTICS := \
    handset

-include \
    $(LOCAL_PATH)/system.prop

# Include our source-built RRO
PRODUCT_PACKAGES += \
    TrebleOverlayInfinixHot10

# 1. Copy Telephony Tables
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/configs/telephony/apns-conf.xml:$(TARGET_COPY_OUT_PRODUCT)/etc/apns-conf.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP01.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP01.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP02.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP02.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP09.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP09.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP12.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP12.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP17.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP17.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP18.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP18.xml \
    $(LOCAL_PATH)/configs/telephony/ecc_list_OP20.xml:$(TARGET_COPY_OUT_VENDOR)/etc/ecc_list_OP20.xml

# 2. Copy Initialization Scripts
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/configs/init/init.volte_imcb.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/init.volte_imcb.rc \
    $(LOCAL_PATH)/configs/init/init.volte_imsm_93.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/init.volte_imsm_93.rc \
    $(LOCAL_PATH)/configs/init/init.volte_md_status.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/init.volte_md_status.rc \
    $(LOCAL_PATH)/configs/init/init.volte_stack.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/init.volte_stack.rc \
    $(LOCAL_PATH)/configs/init/init.volte_ua.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/init.volte_ua.rc \
    $(LOCAL_PATH)/configs/init/mtkrild.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/mtkrild.rc

# 3. Copy Hardware Permission Tables
PRODUCT_COPY_FILES += \
    $(call find-copy-files,$(LOCAL_PATH)/configs/permissions,$(TARGET_COPY_OUT_VENDOR)/etc/permissions)

# 4. Copy 32-bit Telephony, Camera Tuning & Audio Libraries
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/vendor/lib/libccci_util.so:$(TARGET_COPY_OUT_VENDOR)/lib/libccci_util.so \
    $(LOCAL_PATH)/vendor/lib/libipsec_ims_shr.so:$(TARGET_COPY_OUT_VENDOR)/lib/libipsec_ims_shr.so \
    $(LOCAL_PATH)/vendor/lib/libreference-ril.so:$(TARGET_COPY_OUT_VENDOR)/lib/libreference-ril.so \
    $(LOCAL_PATH)/vendor/lib/libril.so:$(TARGET_COPY_OUT_VENDOR)/lib/libril.so \
    $(LOCAL_PATH)/vendor/lib/librilutils.so:$(TARGET_COPY_OUT_VENDOR)/lib/librilutils.so \
    $(LOCAL_PATH)/vendor/lib/libvolte_core_shr.so:$(TARGET_COPY_OUT_VENDOR)/lib/libvolte_core_shr.so \
    $(LOCAL_PATH)/vendor/lib/libvolte_xdmc_shr.so:$(TARGET_COPY_OUT_VENDOR)/lib/libvolte_xdmc_shr.so \
    $(LOCAL_PATH)/vendor/lib/lib_speech_enh.so:$(TARGET_COPY_OUT_VENDOR)/lib/lib_speech_enh.so \
    $(LOCAL_PATH)/vendor/lib/libspeech_enh_lib.so:$(TARGET_COPY_OUT_VENDOR)/lib/libspeech_enh_lib.so \
    $(LOCAL_PATH)/vendor/lib/libaudio_param_parser-vnd.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudio_param_parser-vnd.so \
    $(LOCAL_PATH)/vendor/lib/libaudiocompensationfilter_vendor.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiocompensationfilter_vendor.so \
    $(LOCAL_PATH)/vendor/lib/libaudiocomponentengine_vendor.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiocomponentengine_vendor.so \
    $(LOCAL_PATH)/vendor/lib/libaudiofmtconv.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiofmtconv.so \
    $(LOCAL_PATH)/vendor/lib/libaudioprimarydevicehalifclient.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudioprimarydevicehalifclient.so \
    $(LOCAL_PATH)/vendor/lib/libaudiocustparam_vendor.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiocustparam_vendor.so \
    $(LOCAL_PATH)/vendor/lib/libaudiodcrflt_vendor.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiodcrflt_vendor.so \
    $(LOCAL_PATH)/vendor/lib/libaudiotoolkit_vendor.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiotoolkit_vendor.so \
    $(LOCAL_PATH)/vendor/lib/libbluetooth_audio_session_mediatek.so:$(TARGET_COPY_OUT_VENDOR)/lib/libbluetooth_audio_session_mediatek.so \
    $(LOCAL_PATH)/vendor/lib/libaudiocompensationfilterc.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiocompensationfilterc.so \
    $(LOCAL_PATH)/vendor/lib/libaudiocomponentenginec.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudiocomponentenginec.so \
    $(LOCAL_PATH)/vendor/lib/libaudioloudc.so:$(TARGET_COPY_OUT_VENDOR)/lib/libaudioloudc.so \
    $(LOCAL_PATH)/vendor/lib/gc02m1b_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/gc02m1b_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/gc6153_serial_yuv_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/gc6153_serial_yuv_tuning.so \
    $(LOCAL_PATH)/vendor/lib/gc803430fps_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/gc803430fps_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/gc803430fpsext2_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/gc803430fpsext2_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/ov02b1b_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/ov02b1b_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/ov2685_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/ov2685_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/s5k3p9sx_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/s5k3p9sx_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/pblgc02m1b_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/pblgc02m1b_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/pblgc6153_serial_yuv_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/pblgc6153_serial_yuv_tuning.so \
    $(LOCAL_PATH)/vendor/lib/pblgc803430fps_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/pblgc803430fps_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/pblgc803430fpsext2_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/pblgc803430fpsext2_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib/pblcov2685_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib/pblcov2685_mipi_raw_tuning.so

# 5. Copy 64-bit Telephony & Camera Tuning Libraries
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/vendor/lib64/libccci_util.so:$(TARGET_COPY_OUT_VENDOR)/lib64/libccci_util.so \
    $(LOCAL_PATH)/vendor/lib64/libipsec_ims_shr.so:$(TARGET_COPY_OUT_VENDOR)/lib64/libipsec_ims_shr.so \
    $(LOCAL_PATH)/vendor/lib64/libmtk-ril.so:$(TARGET_COPY_OUT_VENDOR)/lib64/libmtk-ril.so \
    $(LOCAL_PATH)/vendor/lib64/libmtk-rilop.so:$(TARGET_COPY_OUT_VENDOR)/lib64/libmtk-rilop.so \
    $(LOCAL_PATH)/vendor/lib64/libmtkrilutils.so:$(TARGET_COPY_OUT_VENDOR)/lib64/libmtkrilutils.so \
    $(LOCAL_PATH)/vendor/lib64/libril.so:$(TARGET_COPY_OUT_VENDOR)/lib64/libril.so \
    $(LOCAL_PATH)/vendor/lib64/librilfusion.so:$(TARGET_COPY_OUT_VENDOR)/lib64/librilfusion.so \
    $(LOCAL_PATH)/vendor/lib64/librilutils.so:$(TARGET_COPY_OUT_VENDOR)/lib64/librilutils.so \
    $(LOCAL_PATH)/vendor/lib64/android.hardware.camera.provider@2.4-impl-mediatek.so:$(TARGET_COPY_OUT_VENDOR)/lib64/android.hardware.camera.provider@2.4-impl-mediatek.so \
    $(LOCAL_PATH)/vendor/lib64/gc02m1b_mipi_raw_IdxMgr.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc02m1b_mipi_raw_IdxMgr.so \
    $(LOCAL_PATH)/vendor/lib64/gc02m1b_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc02m1b_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib64/gc6153_serial_yuv_IdxMgr.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc6153_serial_yuv_IdxMgr.so \
    $(LOCAL_PATH)/vendor/lib64/gc6153_serial_yuv_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc6153_serial_yuv_tuning.so \
    $(LOCAL_PATH)/vendor/lib64/gc803430fps_mipi_raw_IdxMgr.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc803430fps_mipi_raw_IdxMgr.so \
    $(LOCAL_PATH)/vendor/lib64/gc803430fps_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc803430fps_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib64/gc803430fpsext2_mipi_raw_IdxMgr.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc803430fpsext2_mipi_raw_IdxMgr.so \
    $(LOCAL_PATH)/vendor/lib64/gc803430fpsext2_mipi_raw_tuning.so:$(TARGET_COPY_OUT_VENDOR)/lib64/gc803430fpsext2_mipi_raw_tuning.so \
    $(LOCAL_PATH)/vendor/lib64/lib3a.ae.core.so:$(TARGET_COPY_OUT_VENDOR)/lib64/lib3a.ae.core.so \
    $(LOCAL_PATH)/vendor/lib64/lib3a.ae.so:$(TARGET_COPY_OUT_VENDOR)/lib64/lib3a.ae.so

# 6. Automated Directory Clones for hw and soundfx Folders
PRODUCT_COPY_FILES += \
    $(call find-copy-files,$(LOCAL_PATH)/vendor/lib/hw,$(TARGET_COPY_OUT_VENDOR)/lib/hw) \
    $(call find-copy-files,$(LOCAL_PATH)/vendor/lib64/hw,$(TARGET_COPY_OUT_VENDOR)/lib64/hw) \
    $(call find-copy-files,$(LOCAL_PATH)/vendor/lib/soundfx,$(TARGET_COPY_OUT_VENDOR)/lib/soundfx) \
    $(call find-copy-files,$(LOCAL_PATH)/vendor/lib64/soundfx,$(TARGET_COPY_OUT_VENDOR)/lib64/soundfx)
